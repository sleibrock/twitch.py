#!/usr/bin/env python
#-*- coding:utf-8 -*-

__version__ = "2.0.0"

__author__  = "Steven L"
__email__   = "leibrockoli@gmail.com"
__url__     = "http://github.com/leibrockoli/Twitch.py"
__license__ = "MIT"
__authors__ = [__author__]
__status__  = "Development"
