from distutils.core import setup
from Twitch.lib import __author__, __email__, __version__

files = [] 

setup(name="twitch",
    version=__version__,
    description="Access Twitch from the Shell",
    author=__author__,
    author_email=__email__,
    url="http://github.com/leibrockoli/Twitch",
    packages=["Twitch"],
    scripts=['twitch'],
    long_description="""Nothin""",
    )
